#include "Thunder.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include <algorithm>

USING_NS_CC;

using namespace CocosDenshion;

Scene* Thunder::createScene() {
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = Thunder::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

bool Thunder::init() {
    if ( !Layer::init() ) {
        return false;
    }

    visibleSize = Director::getInstance()->getVisibleSize();

    auto bgsprite = Sprite::create("background.jpg");
    bgsprite->setPosition(visibleSize / 2);
    // bgsprite->setScale(visibleSize.width / bgsprite->getContentSize().width, \
    //     visibleSize.height / bgsprite->getContentSize().height);
    this->addChild(bgsprite, 0);

    player = Sprite::create("player.png");
    player->setPosition(visibleSize.width / 2, player->getContentSize().height + 5);
    player->setName("player");
    this->addChild(player, 1);

    addEnemy(5);

    preloadMusic();
    playBgm();

    addTouchListener();
    addKeyboardListener();
    addCustomListener();

    // TODO
    // add schedule
	schedule(schedule_selector(Thunder::update), 0.05f, kRepeatForever, 0);

    return true;
}

void Thunder::preloadMusic() {
    
	auto audio = SimpleAudioEngine::getInstance();

	audio->preloadBackgroundMusic("music/bgm.mp3");
	audio->preloadEffect("music/explore.wav");
	audio->preloadEffect("music/fire.wav");
}

void Thunder::playBgm() {
    // TODO
	auto audio = SimpleAudioEngine::getInstance();
	audio->playBackgroundMusic("music/bgm.mp3");

}

void Thunder::addEnemy(int n) {
    enemys.resize(n * 3);
    for(unsigned i = 0; i < 3; ++i) {
        char enemyPath[20];
        sprintf(enemyPath, "stone%d.png", 3 - i);
        double width  = (visibleSize.width - 20) / (n + 1.0),
               height = visibleSize.height - (50 * (i + 1));
        for(int j = 0; j < n; ++j) {
            auto enemy = Sprite::create(enemyPath);
            enemy->setAnchorPoint(Vec2(0.5, 0.5));
            enemy->setScale(0.5, 0.5);
            enemy->setPosition(width * (j + 1), height);
            enemys[i * n + j] = enemy;
			addChild(enemy);
        }
    }
}

void Thunder::addTouchListener(){
	auto touchListener = EventListenerTouchOneByOne::create();
	touchListener->onTouchBegan = CC_CALLBACK_2(Thunder::onTouchBegan, this);
	touchListener->onTouchMoved = CC_CALLBACK_2(Thunder::onTouchMoved, this);
	touchListener->onTouchEnded = CC_CALLBACK_2(Thunder::onTouchEnded, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, player);
}

void Thunder::addKeyboardListener() {
	auto keyboardListener = EventListenerKeyboard::create();
	keyboardListener->onKeyPressed = CC_CALLBACK_2(Thunder::onKeyPressed, this);
	keyboardListener->onKeyReleased = CC_CALLBACK_2(Thunder::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(keyboardListener, player);
}

void Thunder::update(float f) {
	if (player == NULL)
		return;
	if (player->getPositionX() + move < visibleSize.width-5 && player->getPositionX() + move >  35)
		player->setPosition(player->getPosition() + Vec2(move, 0));
	static double count = 0;
	static int dir = 1;
	static int y_dir = 1;
	count += f;
	if (count > 1) { count = 0.0; dir = -dir; y_dir = 1 - y_dir; }

	if (bullet != NULL) {
		bullet->setPosition(bullet->getPositionX(), bullet->getPositionY() + 5);
		if (bullet->getPositionY() > visibleSize.height - 10) {
			bullet->removeFromParentAndCleanup(true);
			bullet = NULL;
		}
	}

	for (unsigned i = 0; i < enemys.size(); i++) {
		if (enemys[i] != NULL) {
			enemys[i]->setPosition(enemys[i]->getPosition() + Vec2(dir, -1*y_dir));
			if (bullet != NULL && bullet->getPosition().getDistance(enemys[i]->getPosition()) < 30) {
				EventCustom e("meet");
				e.setUserData(&i);
				_eventDispatcher->dispatchEvent(&e);
			}
			if (player != NULL && player->getPosition().getDistance(enemys[i]->getPosition()) < 30) {
				EventCustom _e("player_meet");
				_e.setUserData(&i);
				_eventDispatcher->dispatchEvent(&_e);
			}
		}
    }
}

void Thunder::fire() {
    if (bullet != NULL) return;
    bullet = Sprite::create("bullet.png");
    bullet->setPosition(player->getPosition());
	addChild(bullet);
	auto audio = SimpleAudioEngine::getInstance();
	audio->playEffect("music/fire.wav", false, 1.0f, 1.0f, 1.0f);
}

void Thunder::addCustomListener() {
    // TODO
	auto meetListener = EventListenerCustom::create("meet", CC_CALLBACK_1(Thunder::meet, this));
	_eventDispatcher->addEventListenerWithFixedPriority(meetListener, 1);
	auto playerMeetListener = EventListenerCustom::create("player_meet", CC_CALLBACK_1(Thunder::player_meet, this));
	_eventDispatcher->addEventListenerWithFixedPriority(playerMeetListener, 1);

}

bool Thunder::onTouchBegan(Touch *touch, Event *unused_event) {
	Vec2 position =  touch->getLocation();
	if (position.x > player->getPositionX()) {
		player->setPosition(player->getPositionX(), player->getPositionY());
		move += 5;
	}
	else {
		player->setPosition(player->getPositionX(), player->getPositionY());
		move -= 5;
	}
	return true;
}

void Thunder::onTouchMoved(Touch *touch, Event *unused_event) {
	Vec2 position = touch->getLocation();
	Vec2 pre_position = touch->getPreviousLocation();
	if (position.x > pre_position.x && move <= 0) {
		player->setPosition(player->getPositionX(), player->getPositionY());
		move += 5;
	}
	else if (position.x < pre_position.x && move >= 0){
		player->setPosition(player->getPositionX(), player->getPositionY());
		move -= 5;
	}
}

void Thunder::onTouchEnded(Touch *touch, Event *unused_event) {
	move = 0;
	fire();
}

void Thunder::onKeyPressed(EventKeyboard::KeyCode code, Event* event) {
    switch (code) {
        case cocos2d::EventKeyboard::KeyCode::KEY_LEFT_ARROW:
        case cocos2d::EventKeyboard::KeyCode::KEY_A:
			player->setPosition(player->getPositionX(), player->getPositionY());
			move -= 5;
            break;
        case cocos2d::EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
        case cocos2d::EventKeyboard::KeyCode::KEY_D:
			player->setPosition(player->getPositionX(), player->getPositionY());
			move += 5;
            break;
        case cocos2d::EventKeyboard::KeyCode::KEY_SPACE:
            fire();
            break;
        default:
            break;
    }
}

void Thunder::onKeyReleased(EventKeyboard::KeyCode code, Event* event) {
	// TODO

	switch (code) {
	case cocos2d::EventKeyboard::KeyCode::KEY_LEFT_ARROW:
	case cocos2d::EventKeyboard::KeyCode::KEY_A:
		player->setPosition(player->getPositionX(), player->getPositionY());
		move += 5;
		break;
	case cocos2d::EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
	case cocos2d::EventKeyboard::KeyCode::KEY_D:
		player->setPosition(player->getPositionX(), player->getPositionY());
		move -= 5;
		break;
	default:
		break;
	}

}


void Thunder::meet(EventCustom* event) {
	void *data = event->getUserData();

	int i = *((int *)data);
	bullet->removeFromParentAndCleanup(true);
	bullet = NULL;

	enemys[i]->removeFromParentAndCleanup(true);
	enemys.erase(enemys.begin() + i);

	auto audio = SimpleAudioEngine::getInstance();
	audio->playEffect("music/explore.wav", false, 1.0f, 1.0f, 1.0f);
}
void Thunder::player_meet(EventCustom* event) {
	void *data = event->getUserData();

	int i = *((int *)data);
	player->removeFromParentAndCleanup(true);
	player = NULL;

	enemys[i]->removeFromParentAndCleanup(true);
	enemys.erase(enemys.begin() + i);

	auto audio = SimpleAudioEngine::getInstance();
	audio->playEffect("music/explore.wav", false, 1.0f, 1.0f, 1.0f);
}
