#include"Monster.h"
USING_NS_CC;

Factory* Factory::factory = NULL;
Factory::Factory() {
	initSpriteFrame();
}
Factory* Factory::getInstance() {
	if (factory == NULL) {
		factory = new Factory();
	}
	return factory;
}
void Factory::initSpriteFrame(){
	auto texture = Director::getInstance()->getTextureCache()->addImage("Monster.png");
	monsterDead.reserve(4);
	for (int i = 0; i < 4; i++) {
		auto frame = SpriteFrame::createWithTexture(texture, CC_RECT_PIXELS_TO_POINTS(Rect(258-48*i,0,42,42)));
		monsterDead.pushBack(frame);
	}
}

Sprite* Factory::createMonster() {
	Sprite* mons = Sprite::create("Monster.png", CC_RECT_PIXELS_TO_POINTS(Rect(364,0,42,42)));
	monster.pushBack(mons);
	return mons;
}

void Factory::removeMonster(Sprite* sp) {

			Animation* animation = Animation::createWithSpriteFrames(monsterDead, 0.1f);
			Animate* animate = Animate::create(animation);
			Sequence* seq = Sequence::create(animate, CallFunc::create(CC_CALLBACK_0(Sprite::removeFromParent, sp)), NULL);
			sp->runAction(seq);
			monster.eraseObject(sp);

}
void Factory::moveMonster(Vec2 playerPos,float time){

}

Sprite* Factory::collider(Rect playerRect) {
	Rect colliderBox = Rect(playerRect.getMinX(), playerRect.getMinY(), playerRect.getMaxX() - playerRect.getMinX(), playerRect.getMaxY() - playerRect.getMinY());
	for (Vector<Sprite*>::iterator i = monster.begin(); i != monster.end(); i++) {
		if (colliderBox.containsPoint((*i)->getPosition())) {
			return *i;
		}
	}
	return NULL;
}


Sprite* Factory::attackMonster(Rect playerRect) {
	Rect colliderBox = Rect(playerRect.getMinX() - 20, playerRect.getMinY(), playerRect.getMaxX() - playerRect.getMinX() + 40, playerRect.getMaxY() - playerRect.getMinY());
	for (Vector<Sprite*>::iterator i = monster.begin(); i != monster.end(); i++) {
		if (colliderBox.containsPoint((*i)->getPosition())) {
			return *i;
		}
	}
	return NULL;
}

void Factory::allMonsterRun(Vec2 playerPos) {
	for (Vector<Sprite*>::iterator i = monster.begin(); i != monster.end(); i++) {
		Vec2 monsterPos = (*i)->getPosition();
		Vec2 direction = playerPos - monsterPos;
		direction.normalize();
		(*i)->runAction(MoveBy::create(0.5f, direction * 30));
	}
}