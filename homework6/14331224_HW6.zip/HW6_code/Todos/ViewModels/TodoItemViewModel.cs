﻿using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Popups;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace Todos.ViewModels
{
    class TodoItemViewModel
    {
        private ObservableCollection<Models.TodoItem> allItems = new ObservableCollection<Models.TodoItem>();
        public ObservableCollection<Models.TodoItem> AllItems { get { return this.allItems; } }

        private Models.TodoItem selectedItem = default(Models.TodoItem);
        public Models.TodoItem SelectedItem { get { return selectedItem; } set { this.selectedItem = value; } }

        private Models.TodoItem updatedItem = default(Models.TodoItem);
        public Models.TodoItem UpdatedItem { get { return updatedItem; } set { this.updatedItem = value; } }

        public TodoItemViewModel()
        {
            // 加入两个用来测试的item
            LoadAllTodoItem();
        }
        public void LoadAllTodoItem()
        {
            var db = App.conn;
            string sql = @"SELECT Id, Title, Context, Date FROM TodoItem";
            using (var statement = db.Prepare(sql)) {
                while (SQLiteResult.ROW == statement.Step()) {
                    this.allItems.Add(new Models.TodoItem((long)statement[0],(string)statement[1], (string)statement[2], DateTimeOffset.Parse((string)statement[3]), new BitmapImage(new Uri("ms-appx:///Assets/background.jpg"))));
                }
            }
        }

        public void AddTodoItem(string title, string description, DateTimeOffset date, ImageSource image)
        {
            var db = App.conn;
            try
            {
                string sql = @"INSERT INTO 
                             TodoItem (Title, Context, Date)
                             VALUES(?,?,?)";
                using (var statement = db.Prepare(sql))
                {
                    statement.Bind(1, title);
                    statement.Bind(2, description);
                    statement.Bind(3, date.ToString());
                    statement.Step();
                }
            }
            catch (Exception e) {

            }
            long temp = 0;
            string sql_ = @"SELECT Id, Title, Context, Date FROM TodoItem";
            using (var statement = db.Prepare(sql_))
            {
                while (SQLiteResult.ROW == statement.Step())
                {
                    temp = (long)statement[0];
                }
            }
            this.allItems.Add(new Models.TodoItem(temp, title, description, date, image));
        }

        public void RemoveTodoItem()
        {
            // DIY
            allItems.RemoveAt(allItems.IndexOf(selectedItem));
            var db = App.conn;
            using (var statement = db.Prepare("DELETE FROM TodoItem WHERE Id  = ?")) {
                statement.Bind(1, selectedItem.id);
                statement.Step();
            }

                // set selectedItem to null after remove
                this.selectedItem = null;
        }

        public void UpdateTodoItem(string title, string description, DateTimeOffset date, ImageSource image)
        {
            // DIY
            this.selectedItem.title = title;
            this.selectedItem.description = description;
            this.selectedItem.date = date;
            this.selectedItem.image = image;

            var db = App.conn;
            using (var statement = db.Prepare("UPDATE TodoItem SET Title = ?, Context = ?, Date = ? WHERE Id = ?"))
            {
                statement.Bind(1, title);
                statement.Bind(2, description);
                statement.Bind(3, date.ToString());
                statement.Bind(4, selectedItem.id);
                statement.Step();
            }

                // set selectedItem to null after update


                this.selectedItem = null;
        }
        public string  QueryALLTodoItem() {
            string temp = "";
            var db = App.conn;
            string sql = @"SELECT Id, Title, Context, Date FROM TodoItem";
            using (var statement = db.Prepare(sql))
            {
                while (SQLiteResult.ROW == statement.Step())
                {
                    temp += "Id : " + (long)statement[0] + ";" + "Title : " + (string)statement[1] + ";" + "Context : " + (string)statement[2] + ";" + "Date : " + (string)statement[3] + "\n";
                }
            }
            return temp;
        }

        public string QueryTodoItemByKey(string key)
        {
            string temp = "";
            var db = App.conn;
            string sql = @"SELECT Id, Title, Context, Date
                           FROM TodoItem
                           WHERE ID LIKE ? OR Title LIKE ? OR Context LIKE ? OR Date LIKE ?";
            using (var statement = db.Prepare(sql))
            {
                statement.Bind(1, "%" + key + "%");
                statement.Bind(2, "%" + key + "%");
                statement.Bind(3, "%" + key + "%");
                statement.Bind(4, "%" + key + "%");
                while (SQLiteResult.ROW == statement.Step())
                {
                    temp += "Id : " + (long)statement[0] + ";" + "Title : " + (string)statement[1] + ";" + "Context : " + (string)statement[2] + ";" + "Date : " + (string)statement[3] + "\n";
                }
            }
            return temp;
        }

    }
}
