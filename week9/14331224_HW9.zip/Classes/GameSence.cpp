﻿#include "GameSence.h"

USING_NS_CC;

Scene* GameSence::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = GameSence::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
bool GameSence::init()
{

	if (!Layer::init())
	{
		return false;
	}

	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();
	//backgram
	auto bg = Sprite::create("level-background-0.jpg");
	bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	this->addChild(bg, 0);
	auto shoot = MenuItemLabel::create(Label::create("Shoot", "Marker Felt", 60),CC_CALLBACK_1(GameSence::Shoot_Mouse, this));
	shoot->setPosition(Vec2(visibleSize.width / 2 + origin.x+ 200, visibleSize.height / 2 + origin.y+200));

	auto menu_ = Menu::create(shoot, NULL);
	menu_->setPosition(Vec2::ZERO);
	this->addChild(menu_, 1);



	this -> mouseLayer = Layer::create();
	this -> stoneLayer = Layer::create();
	mouseLayer->setAnchorPoint(Vec2(0, 0));
	mouseLayer->setPosition(Vec2(0, visibleSize.height/2));
	stoneLayer->setAnchorPoint(Vec2(0, 0));
	stoneLayer->setPosition(Vec2(0, 0));


	//mouse
	this->mouse = Sprite::createWithSpriteFrameName("gem-mouse-0.png");
	Animate* mouseAnimate = Animate::create(AnimationCache::getInstance()->getAnimation("mouseAnimation"));
	mouse->runAction(RepeatForever::create(mouseAnimate));
	mouse->setPosition(Vec2(visibleSize.width / 2 + origin.x, 0));
	mouseLayer->addChild(mouse, 0);


	//stone

	this->stone = Sprite::create("stone.png");
	stone->setPosition(Vec2(560 , 480));
	stoneLayer->addChild(stone, 0);




	//add to layer
	this->addChild(mouseLayer,1);
	this->addChild(stoneLayer, 2);
	


	//add touch listener
	EventListenerTouchOneByOne* listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = CC_CALLBACK_2(GameSence::onTouchBegan, this);
	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);


	


	




	return true;
}

bool GameSence::onTouchBegan(Touch *touch, Event *unused_event) {

	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();

	auto location = touch->getLocation();
	auto cheese = Sprite::create("cheese.png");
	cheese->setPosition(Vec2(location.x, location.y));
	this->addChild(cheese, 0);

	Vec2 temp = mouseLayer->convertToNodeSpace(Vec2(location.x, location.y));
	auto moveTo = MoveTo::create(2, temp);
	mouse->runAction(moveTo);
	auto fadeIn = FadeIn::create(2.0f);
	auto fadeOut = FadeOut::create(1.5f);
	auto seq = Sequence::create(fadeIn, fadeOut, nullptr);
	cheese->runAction(seq);
	return true;
}

void GameSence::Shoot_Mouse(cocos2d::Ref* pSender) {
	auto location = mouseLayer -> convertToWorldSpace(mouse->getPosition());
	auto temp_stone = Sprite::create("stone.png");
	temp_stone->setPosition(Vec2(560, 480));
	stoneLayer->addChild(temp_stone, 1);
	Vec2 temp = stoneLayer->convertToNodeSpace(Vec2(location.x, location.y));

	auto gem = Sprite::create("diamond.png");
	gem->setPosition(mouse->getPosition());
	mouseLayer->addChild(gem, 1);
	

	auto moveTo = MoveTo::create(0.9, temp);
	auto fadeIn = FadeIn::create(2.0f);
	auto fadeOut = FadeOut::create(1.0f);

	auto moveTo_ = MoveTo::create(0.9, Vec2(50,0));
	auto seq = Sequence::create(moveTo, fadeOut, nullptr);
	gem->runAction(fadeIn);
	temp_stone->runAction(seq);
	mouse->runAction(moveTo_);
}
